package es.tuespiral.spring.modelo;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Optional;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import es.tuespiral.spring.*;



@Entity	
@Table(name="Solicita_Prueba")


public class SolicitaPrueba {
	
	@Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Long id;
	
	@ManyToOne
	private Cliente cliente;
	
	@ManyToOne
	private vehiculo vehiculo;
	
	
	@Column(name="HoraPrueba", nullable=true)
	private LocalTime testHour;
	
	@Column(name="FechaPrueba", nullable=true)
	private LocalDate testDate;
	
	@Column(name="realizacion",length=50, nullable=true)
	private String realizaTest;
	
	

	public SolicitaPrueba() {
		super();
	}

	

	public SolicitaPrueba(Cliente cliente, vehiculo vehiculo, LocalTime testHour, LocalDate testDate,
			String realizaTest) {
		super();
		
		this.cliente = cliente;
		this.vehiculo = vehiculo;
		this.testHour = testHour;
		this.testDate = testDate;
		this.realizaTest = realizaTest;
	}



	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Cliente getCliente() {
		return cliente;
	}

	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}

	public vehiculo getVehiculo() {
		return vehiculo;
	}

	public void setVehiculo(vehiculo vehiculo) {
		this.vehiculo = vehiculo;
	}

	public LocalTime getTestHour() {
		return testHour;
	}

	public void setTestHour(LocalTime testHour) {
		this.testHour = testHour;
	}

	public LocalDate getTestDate() {
		return testDate;
	}

	public void setTestDate(LocalDate testDate) {
		this.testDate = testDate;
	}

	public String isRealizaTest() {
		return realizaTest;
	}

	public void setRealizaTest(String realizaTest) {
		this.realizaTest = realizaTest;
	}



	
	

}