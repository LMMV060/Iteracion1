package es.tuespiral.spring;

import java.math.BigDecimal;
import java.util.List;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import es.tuespiral.spring.modelo.*;



@SpringBootApplication
public class RelacionesJpaApplication {

	public static void main(String[] args) {
		ApplicationContext context = SpringApplication.run(RelacionesJpaApplication.class, args);
		
		
		ClienteRepository newCliente = context.getBean(ClienteRepository.class);
		ConcesionarioRepository newConcesionario = context.getBean(ConcesionarioRepository.class);
		VehiculoRepository newVehiculo = context.getBean(VehiculoRepository.class);
		
		
		Cliente c = new Cliente("Alfredo", "Barca");
		
		c.setEmail("lmmv060@gmail.com");
		c.setFecha("20-20-20");
		c.setId((long)1);
		c.setNIF("49826060X");
		c.setTelefono(618381630);
		
		//c = newCliente.findById((long)1).get();
		
		Concesionario con = new Concesionario();
		con.setDireccion("C/Capitán Cala");
		con.setEmail("empresa@original.com");
		con.setFecha("20-20-20");
		con.setHorario("20:00 - 21:00");
		con.setId((long)1);
		con.setNombre("BearBikes");
		con.setTelefono(618381630);
		
		vehiculo v = new vehiculo();
		
		v.setAnyo(1990);
		v.setCilindrada("Se pone en numeros verdad?  190");
		v.setId((long)1);
		v.setMarca("marca");
		v.setMatricula("1234C");
		v.setModelo("modelo");
		v.setNum(123456);
		v.setPotencia(80);
		v.setPrecio(12000);
		
		newCliente.save(c);
		newConcesionario.save(con);
		newVehiculo.save(v);
	}

}
