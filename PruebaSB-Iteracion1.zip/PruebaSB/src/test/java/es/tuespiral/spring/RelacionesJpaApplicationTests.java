package es.tuespiral.spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RelacionesJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
